/**
 * iss 2014302580178
 * �޾���
 * get teacher information
 */
import java.io.*;
import java.util.regex.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.parser.*;
import org.jsoup.select.*;

import com.github.kevinsawicki.http.*;

public class Main2014302580178 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String url = "http://www.bio.whu.edu.cn/News_reads.asp?cid=174&id=1488";
		String Email="", Phone="", Diraction="";
		String[][] content = new String[5][2];
		int i = 0;//ѭ���ü�����
		HttpRequest get;
		get = HttpRequest.get(url);
		File output = new File("out.html");
		get.receive(output);
		try {
			Document html = Jsoup.parse(output, "GB2312");

			Element name = html.getElementsByTag("table").first()
					.getElementsByTag("table").first().getElementsByTag("b")
					.first();
			String Tname = name.text();// ����
			// System.out.println(Tname);
			Element body = html.getElementById("newscontent");
			String NExtract = body.toString();// һ��string����Ǻ�һ���������չʾ�������ʽ
			// System.out.println(NExtract);
			Pattern regEx = Pattern.compile("Email:(.*@whu.edu.cn)");// eamil
			Pattern regEx2 = Pattern.compile("027-[0-9]{8}");// phone
			Pattern regEx3 = Pattern
					.compile("\u4e13\u4e1a\u4e0e\u7814\u7a76\u65b9\u5411.*<");// ���з���
			Matcher email = regEx.matcher(NExtract);
			Matcher phone = regEx2.matcher(NExtract);
			Matcher diraction = regEx3.matcher(NExtract);
			while (email.find()) {
				Email = email.group();
			}
			while (phone.find()) {
				Phone = phone.group();
			}
			while (diraction.find()) {
				Diraction = diraction.group().replace('<', ' ');
			}
			Elements zt1 = body.getElementsByClass("zt1");// subtitile
			for (Element head1 : zt1) {
				content[i][0] = head1.text();// save
				i++;
			}
			Elements zt = body.getElementsByClass("zt");// sub content
			i = 0;
			for (Element head2 : zt) {
				content[i][1] = head2.text();// save
				i++;
			}
			FileOutputStream out = new FileOutputStream(new File("text.txt"));
			PrintStream p = new PrintStream(out);
			//��֮ǰ�����������������txt
			p.println(Tname);
			p.println(Email);
			p.println("�绰��"+Phone);
			p.println("רҵ���о�����"+Diraction);
			for(i=0;i<4;i++){
				p.println(content[i][0]);
				p.print(content[i][1]);
				p.println();
			}
			
			p.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
